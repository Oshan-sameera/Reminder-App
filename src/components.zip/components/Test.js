import React from "react";

// const LoadData= async ()=>{
//   const url=""
//   try{
//   const res= await fetch(url);
//   const data= awiat res.json();
//    return data;
//   }
//   catch(err){
//     console.log(err);
//   }
// }
const Test = () => {
  return <div></div>;
};

export const xx = () => {
  return (
    <div>
      <h2>Cllieck me</h2>
      <button>Abc</button>
    </div>
  );
};

export default Test;
